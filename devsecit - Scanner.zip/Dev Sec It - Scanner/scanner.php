<?php 
/*
    Plugin name: DEV SEC IT - Scanner
    Version: 1.4.3(beta)
    Author: Kanai Shil - DEV SEC IT
    Author uri: https://devsecit.com/author/webdeveloperkanai
    Plugin uri: https://devsecit.com/plugin/wp-scanner
    Description: Auto clear all garbage files of your hosting and keep safe your website. Set a cron job for <a href="/?check=true" target="_blank" > check files</a>. 
    <strong> Get help from our website - <a href="https://devsecit.com"> documentation </a> </strong> 
*/

if (isset($_GET['check'])) {
    // chdir("../");

    $allowed = [
        "index.php", "readme.txt", "wp-content", "wp-admin", "wp-includes", "wp-activate.php", "wp-blog-header.php", "wp-comments-post.php", "wp-config.php",
        "wp-cron.php", "wp-links-opml.php", "wp-load.php", "wp-login.php", "wp-mail.php", "wp-settings.php", "wp-signup.php", "wp-trackback.php", "xmlrpc.php", "sdk"
    ];

    if (isset($_GET['path'])) {
        $rootPath = realpath('../' . $_GET['path'] . '/');
    } else {
        $path = explode("/public_html", getcwd())[1];
        $root_length = substr_count($path, "/");
        for ($i = 0; $i < $root_length; $i++) {
            chdir("../");
        }
        $rootPath = realpath('' . $_SERVER['DOCUMENT_ROOT'] . '/');
    }

    $f = scandir($rootPath);
    foreach ($f as $fl) {

        if (strlen($fl) > 2) {
            if (in_array($fl, $allowed)) {
            } else {
                //echo $fl . " - Not Allowed <br>";
                try {
                    if (is_dir($fl)) {
                        system("rm -rf " . escapeshellarg($fl));
                    } else {
                        unlink($fl);
                    }
                } catch (\Throwable $th) {
                    //throw $th;
                }
            }
        }
    }
    echo "<script>location.href='/'</script>";
    die(); 
}
?>